import{j as e}from"./vendor-core-DruQiq2h.js";import{D as h,am as v,t as y,f as j}from"./index-Dq6ALjTQ.js";import{p as _,e as a}from"./printHelpers-DZtQIqyB.js";import{a as w}from"./printTicketSmart-DOWfu7Fq.js";import{u as c}from"./vendor-i18n-FHetUBVu.js";import"./vendor-router-C4wACl4t.js";import"./vendor-query-3BtnTsLw.js";import"./vendor-http-n6NG6ckz.js";import"./vendor-radix-B4WhlNZo.js";import"./vendor-ui-D1oWv91c.js";import"./purify.es-BPuvlvQ_.js";import"./ticketEscpos-CVzSpILQ.js";import"./encoder-BCTCVCUb.js";import"./qzPrinter-7sp_yCoD.js";function A({isOpen:m,onClose:l,coupon:t,factureForCoupon:r,onAppliquer:p,settings:x}){const{t:s}=c("caisse"),{lang:b,locale:d}=h(),{t:n}=c("printing",{lng:b}),i=x??{},f=o=>{const g=new Date(o.date_creation).toLocaleString(d,{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"});_(`<!DOCTYPE html>
<html>
<head>
  <title>${a(n("coupon.title"))}</title>
  <style>
    @media print {
      @page {
        size: 80mm auto;
        margin: 0;
      }
      body {
        margin: 0;
        padding: 10mm 5mm;
      }
    }
    body {
      font-family: 'Courier New', monospace;
      width: 80mm;
      margin: 0 auto;
      padding: 10mm 5mm;
      font-size: 11px;
      line-height: 1.4;
      color: #000;
      background: #fff;
    }
    .header {
      text-align: center;
      border-bottom: 2px solid #000;
      padding-bottom: 8px;
      margin-bottom: 12px;
    }
    .pharmacy-name {
      font-size: 16px;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    .pharmacy-info {
      font-size: 10px;
      line-height: 1.3;
    }
    .coupon-box {
      border: 2px dashed #000;
      padding: 15px;
      margin: 15px 0;
      text-align: center;
    }
    .coupon-label {
      font-size: 9px;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 5px;
      font-weight: bold;
    }
    .coupon-number {
      font-size: 24px;
      font-weight: bold;
      margin: 8px 0;
      font-family: 'Courier New', monospace;
    }
    .coupon-amount {
      font-size: 32px;
      font-weight: bold;
      margin: 10px 0;
      color: #000;
    }
    .info-section {
      margin-top: 15px;
      font-size: 10px;
      text-align: left;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 4px;
    }
    .info-label {
      font-weight: bold;
    }
    .status-badge {
      display: inline-block;
      padding: 2px 8px;
      border: 1px solid #000;
      font-size: 9px;
      margin-left: 5px;
    }
    .notes {
      margin-top: 12px;
      padding: 8px;
      background: #f5f5f5;
      border: 1px solid #ddd;
      font-size: 9px;
      font-style: italic;
      text-align: left;
    }
    .footer {
      text-align: center;
      margin-top: 20px;
      padding-top: 10px;
      border-top: 1px solid #000;
      font-size: 9px;
    }
    .warning {
      font-size: 9px;
      color: #666;
      margin-top: 10px;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="pharmacy-name">${a(i.pharmacy_name||n("coupon.pharmacy_fallback"))}</div>
    <div class="pharmacy-info">
      ${i.city?`${a(i.city)}`:""}${i.country?`, ${a(i.country)}`:""}<br>
      ${i.phone?`${n("invoice.tel")}: ${a(i.phone)}`:""}<br>
      ${i.niu?`NIU: ${a(i.niu)}`:""}<br>
      ${i.registre_commerce?`RC: ${a(i.registre_commerce)}`:""}
    </div>
  </div>
  
  <div class="coupon-box">
    <div class="coupon-label">${n("coupon.title")}</div>
    <div class="coupon-number">#${a(o.numero)}</div>
    <div class="coupon-amount">${j(Math.round(Number(o.montant)),d)}</div>
  </div>

  <div class="info-section">
    <div class="info-row">
      <span class="info-label">${n("coupon.status")}:</span>
      <span>${a(o.status_display||o.status)}<span class="status-badge">${a(o.status)}</span></span>
    </div>
    <div class="info-row">
      <span class="info-label">${n("coupon.generated_by")}:</span>
      <span>${a(o.cree_par_nom||n("coupon.system"))}</span>
    </div>
    <div class="info-row">
      <span class="info-label">${n("coupon.date")}:</span>
      <span>${g}</span>
    </div>
    ${o.facture_origine?`
    <div class="info-row">
      <span class="info-label">${n("coupon.origin_invoice")}:</span>
      <span>#${a(o.facture_origine)}</span>
    </div>
    `:""}
  </div>

  ${o.notes?`
  <div class="notes">
    <strong>${n("coupon.notes")}:</strong><br>
    ${a(o.notes)}
  </div>
  `:""}

  <div class="warning">
    ${n("coupon.validity")}
  </div>

  <div class="footer">
    ${a(i.ticket_footer_message||n("ticket.visit_thanks"))}
  </div>
  <script>window.onload = function () { setTimeout(function () { window.print() }, 250) }<\/script>
</body>
</html>`,()=>y.error(s("coupons.details_modal.print_error")))},u=()=>{t&&w(t,i,()=>f(t))};return e.jsx(v,{isOpen:m&&!!t,onClose:l,title:s("coupons.details_modal.title"),icon:e.jsx("span",{className:"text-emerald-600 text-xl",children:"🎫"}),footer:e.jsxs("div",{className:"flex justify-between gap-2 w-full",children:[e.jsx("button",{className:"inline-flex items-center justify-center h-8 px-3 rounded-lg text-xs font-semibold border-2 border-slate-200 text-slate-600 hover:border-emerald-500 hover:text-emerald-600 transition-colors",onClick:u,children:s("coupons.details_modal.print")}),e.jsxs("div",{className:"flex gap-2",children:[e.jsx("button",{className:"inline-flex items-center justify-center h-8 px-3 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors",onClick:l,children:s("coupons.details_modal.close")||"Fermer"}),t&&t.status==="ACTIF"&&r&&e.jsxs("button",{className:"inline-flex items-center justify-center h-8 px-3 rounded-lg text-xs font-semibold bg-emerald-600 text-white shadow-sm hover:bg-emerald-700 transition-colors",onClick:()=>p(t,r),children:[s("table.apply_coupon")," #",r.session_ticket_number]}),t&&t.status==="ACTIF"&&!r&&e.jsx("div",{className:"text-xs text-amber-600",children:s("coupons.select_sale_first")})]})]}),children:e.jsx("div",{className:"p-6",children:t&&e.jsxs("div",{className:"text-center p-4 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50",children:[e.jsx("div",{className:"text-xs font-bold text-slate-400 uppercase tracking-widest mb-1",children:s("coupons.coupon_label")}),e.jsxs("div",{className:"text-4xl font-black text-emerald-600 font-mono mb-2",children:["#",t.numero]}),e.jsxs("div",{className:"text-3xl font-bold text-slate-800 mb-4",children:[Math.round(Number(t.montant))," F"]}),e.jsx("div",{className:"border-t border-slate-200 my-2"}),e.jsxs("div",{className:"text-left space-y-2 text-xs text-slate-700",children:[e.jsxs("div",{className:"flex justify-between",children:[e.jsxs("span",{children:[s("coupons.headers.status"),":"]}),e.jsx("span",{className:`inline-flex items-center px-2 h-5 text-caption rounded font-semibold ${t.status==="ACTIF"?"bg-emerald-100 text-emerald-700":t.status==="UTILISE"?"bg-slate-100 text-slate-700":"bg-slate-50 text-slate-500"}`,children:t.status_display||t.status})]}),e.jsx("div",{className:"border-t border-slate-200 my-1"}),e.jsxs("div",{className:"bg-white p-2 rounded border border-slate-200 space-y-1",children:[e.jsx("div",{className:"font-bold text-caption uppercase text-slate-500 mb-1",children:s("coupons.creation")}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:s("coupons.generated_by")}),e.jsx("span",{className:"font-medium",children:t.cree_par_nom||s("coupons.system")})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:s("table.date")}),e.jsx("span",{className:"font-medium",children:new Date(t.date_creation).toLocaleDateString("fr-FR",{day:"2-digit",month:"2-digit",year:"numeric"})})]})]}),t.status==="UTILISE"&&e.jsxs("div",{className:"bg-emerald-50 p-2 rounded border border-emerald-100 space-y-1",children:[e.jsx("div",{className:"font-bold text-caption uppercase text-emerald-600 text-slate-500 mb-1",children:s("coupons.headers.usage")}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:s("coupons.used_by")}),e.jsx("span",{className:"font-medium",children:t.utilise_par_nom||s("coupons.na")})]}),t.date_utilisation&&e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:s("table.date")}),e.jsx("span",{children:new Date(t.date_utilisation).toLocaleDateString("fr-FR",{day:"2-digit",month:"2-digit",year:"numeric"})})]})]}),t.notes&&e.jsxs("div",{className:"mt-2 p-2 bg-white rounded italic border border-slate-200 text-slate-600",children:[e.jsxs("span",{className:"font-bold not-italic text-slate-500 block text-caption mb-1",children:[s("coupons.notes_label"),":"]}),'"',t.notes,'"']})]})]})})})}export{A as CouponDetailsModal};
